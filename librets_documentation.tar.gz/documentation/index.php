<?php $tmpl_title = "Documentation";
$tmpl_location = "Documentation";
      include("../header.php");
?>
    <h3>Documentation</h3>
    <p>
        The <a href="api/">API documentation</a>.
        This is based off the C++ version.
    </p>
    <p>
        The <a href="csharp/">.NET API documentation</a> for the .NET
        language bindings of libRETS.  Produced by Matt Lavallee.
    </p>
    <p>
        A <a href="devguide/">developers Quick Start</a> guide covering
        all supported languges.
    </p>
    <p>
        The <a href="https://code.crt.realtors.org/projects//librets/wiki">
        Wiki</a> and <a href="https://code.crt.realtors.org/projects/librets/wiki/FAQ">
        FAQ</a>.
    </p>
    <?php include("../footer.php"); ?>
